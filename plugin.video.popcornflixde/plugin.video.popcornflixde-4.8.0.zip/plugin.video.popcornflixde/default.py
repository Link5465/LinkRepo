#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import urllib,re,os
import xbmcplugin,xbmcgui
import xbmcaddon,xbmc

dialog = xbmcgui.Dialog()
try: 
	import requests
except: 
	dialog.ok("ERROR", "To use this addon you have to install", "script.module.requests")

addon = xbmcaddon.Addon(id='plugin.video.popcornflixde')
home = addon.getAddonInfo('path').decode('utf-8')
image = xbmc.translatePath(os.path.join(home, 'icon.png'))
apiurl = 'http://popcornflixv2.device.screenmedia.net/api/videos/'

pluginhandle = int(sys.argv[1])

def kategorien():
	categories = requests.get(apiurl).json()
	for category in categories:
	  title = category['title'].encode('utf-8')
          addDir(title,apiurl,'subcats',image)
        addDir('Suche','','suche',image)
	xbmcplugin.endOfDirectory(pluginhandle)

def subcats():
	name = params['name']
	categories = requests.get(apiurl).json()
	for category in categories:
	  if category['title'].encode('utf-8') == name:
	     for subcat in category:
	       if not subcat == 'title':
	         name = subcat.encode('utf-8')
	         url = category[subcat]
	         addDir(name,url,'liste',image)
	xbmcplugin.endOfDirectory(pluginhandle)

def liste(url=False):
	if not url: url = apiurl + params['url']
	movies = requests.get(url).json()['movies']
	for movie in movies:
	  guid = movie['guid']
	  title = movie['title'].encode('utf-8')
	  description = movie['description'].encode('utf-8')
	  publishDate = movie['publishDate']
	  directors = movie['directors']
	  genre = movie['genre']
	  poster = movie['poster']
	  duration = movie['duration']
	  rating = movie['rating']
	  try: language = movie['language']
	  except: language = ''
	  if addon.getSetting('sprache') == 'Deutsch' and language == 'German':
	    addLink(title,guid,'play',poster,description,publishDate,directors,genre,duration,rating)
	  elif addon.getSetting('sprache') == 'Alle':
	    addLink(title,guid,'play',poster,description,publishDate,directors,genre,duration,rating)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_TITLE)
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmcplugin.endOfDirectory(pluginhandle)

def play():
	url = params['url']
	url = apiurl + url
	movie = requests.get(url).json()['movies']
	m3u8 = movie[0]['urls']['Web v2 Player']
	content = requests.get(m3u8).content
	streams = re.findall('\n(http.+?)\n', content)
	quality = addon.getSetting('quality')
	if quality == 'Standard': stream = m3u8
	if quality == 'Hoch': stream = streams[-1]
	if quality == 'Niedrig': stream = streams[2]
        listitem = xbmcgui.ListItem(path = stream)
        xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)

def suche():
        kb = xbmc.Keyboard('', 'Search', False)
        kb.doModal()
        search_entered = kb.getText().replace(' ','+')
        url = 'http://popcornflixv2.device.screenmedia.net/api/search/' + search_entered
	liste(url)

def addLink(name,url,mode,iconimage,plot,date,directors,genre,duration,rating):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
        item=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        item.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot, "DateAdded": date, "Director": directors, "Genre": genre, "Duration": duration, "Mpaa": rating } )
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(pluginhandle,url=u,listitem=item)

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        item=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        item.setInfo( type="Video", infoLabels={ "Title": name } )
        xbmcplugin.addDirectoryItem(pluginhandle,url=u,listitem=item,isFolder=True)
              
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
	  params=sys.argv[2]
	  cleanedparams=params.replace('?','')
	  if (params[len(params)-1]=='/'):
	    params=params[0:len(params)-2]
	  pairsofparams=cleanedparams.split('&')
	  param={}
	  for i in range(len(pairsofparams)):
	    splitparams={}
	    splitparams=pairsofparams[i].split('=')
	    if (len(splitparams))==2:
	      param[splitparams[0]]=urllib.unquote_plus(splitparams[1])
	return param

params=get_params()
try:
    mode=params["mode"]
except:
    mode=None
print "Mode: "+str(mode)
print "Parameters: "+str(params)

if mode==None:
  kategorien()
else:
  exec '%s()' % mode