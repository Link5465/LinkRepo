﻿actmsg="xbmcgui.Dialog().yesno('Nueva version disponible: [COLOR=red](v.'+vers+')[/COLOR]','Desea actualizar?',yeslabel='Pues...si',nolabel='Mas tarde')"
messs='plugintools.message("ERROR","[COLOR=yellow]Cambios en la web[/COLOR]","[COLOR=red](avisar en el foro)[/COLOR]")'
nolink='plugintools.message("ATENCION","[COLOR=yellow]Canal sin emisión[/COLOR]","[COLOR=red](no hay enlaces)[/COLOR]")'
noacc='plugintools.message("ATENCION","[COLOR=yellow]Cuenta inactiva[/COLOR]","[COLOR=red](activa tu cuenta!)[/COLOR]")'
noevent='plugintools.message("ATENCION","[COLOR=yellow]No hay eventos[/COLOR]","[COLOR=red](no hay enlaces)[/COLOR]")'
nocode='plugintools.message("ATENCION","[COLOR=yellow]Faltan diccionarios para los enlaces[/COLOR]","[COLOR=red](no hay enlaces)[/COLOR]")'
notf="dialog = xbmcgui.Dialog();dialog.notification(heading=params['title'],message='Ahora no hay partidos!',icon=art+'icon.png',time=5000);";
pxmess='plugintools.message("ATENCION","[COLOR=yellow]Necesita proxy RDS!!![/COLOR]","[COLOR=red](se intenta abrir)[/COLOR]")'
dlg="xbmcgui.Dialog().notification('ESPERE',mssg,icon,timp)"
#http://forum.xda-developers.com/xperia-e3/development/noob-friendly-root-recovery-installation-t2989689